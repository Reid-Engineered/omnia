from pathlib import Path
p=Path('crates/omnia-doc/src/connectivity.rs')
s=p.read_text(); Path('baseline-connectivity.rs').write_text(s)
s=s.replace('let stamp = self.next_visit_gen();','let profile_start = std::time::Instant::now();\n        let stamp = self.next_visit_gen();',1)
s=s.replace('let new_comp = self.alloc_comp(Comp {\n            net: old_net,','let first_ns = profile_start.elapsed().as_nanos();\n        let second_start = std::time::Instant::now();\n        let new_comp = self.alloc_comp(Comp {\n            net: old_net,',1)
s=s.replace('let c2_has_labels = !comp2_labels.is_empty();','let second_ns = second_start.elapsed().as_nanos();\n        eprintln!("phases_ns,{first_ns},{second_ns}");\n        let c2_has_labels = !comp2_labels.is_empty();',1)
p.write_text(s)
